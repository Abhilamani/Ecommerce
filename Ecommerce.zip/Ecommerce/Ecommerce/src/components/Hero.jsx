import React from 'react'

function Hero() {
  return (

        
        <section id="home" class="hero">
    <div class="hero-content">
      <h2>Discover the Taste of Gourmet</h2>
      <p>Fresh, tasty, and made just for you!</p>
      <a href="#menu" class="cta-button">Browse Our Menu</a>
    
      
    
      
    </div>
  </section>


  )
}

export default Hero