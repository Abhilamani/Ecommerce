

function Menu(){
    return(
        <div>
<section id="menu" class="food-categories">
    <h2 class="k">Our Food Categories</h2>
    <div class="categories">
      <div class="category">
        <img src="https://images.unsplash.com/photo-1513104890138-7c749659a591?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8cGl6emF8ZW58MHx8MHx8fDA%3D" alt="pizza"/>
        <h3>Pizza</h3>
      </div>
      <div class="category">
        <img src="https://media.istockphoto.com/id/482964545/photo/arrabiata-pasta.webp?a=1&b=1&s=612x612&w=0&k=20&c=WgBDLDed6qro4H1gamjxl5hWALBdXm6T0UGSU3d6TRo=" alt="Pasta"/>
        <h3>Pasta</h3>
      </div>
      <div class="category">
        <img src="https://media.istockphoto.com/id/523041362/photo/indian-sweets.webp?a=1&b=1&s=612x612&w=0&k=20&c=BSkWs2PihbSS3Jq3wSGr85kc56ecSWLrVzdQUph-mjI=" alt="Desserts"/>
        <h3>Desserts</h3>
      </div>

            <div>
        <img src="https://media.istockphoto.com/id/1345624336/photo/chicken-biriyani.webp?a=1&b=1&s=612x612&w=0&k=20&c=a8j_p9BkWtsSX7WkcqeetigH8PYWXGayIGto9GiehNY= " alt="Biryani" />
        <h3>Biryani</h3>
        
      
      
      </div>
</div>
      </section>

        </div>
    )
}

export default Menu