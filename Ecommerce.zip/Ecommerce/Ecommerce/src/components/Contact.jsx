

function Contact(){
    return(
        <div>
<section id="contact" class="contact">
    <h1>Contact Us</h1>
    <h2>We're here for you</h2>
    <p>Monday-Friday:7am - 7pm</p>
    <p>Saturday:8am-5pm(Only veg)</p>
    <p>Sunday:Holiday</p>
    <p>Phone: 777-777-7777</p>
    <p>Email: info@deliciouseats.com</p>
    <p>Address: 123 Food Street, Tasty Town, Haveri</p>
    <button class="ab">   Live Chat   </button>

  </section>

        </div>
    )
}

export default Contact