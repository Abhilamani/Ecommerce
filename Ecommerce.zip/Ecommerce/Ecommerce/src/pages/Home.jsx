
import Hero from "../components/Hero"
import Navbar from "../components/Navbar"
import Slider from "../components/Slider"
import Footer from "../components/Footer"
function Home(){
    return(
        <div>
            
            <Navbar></Navbar>
            <Hero />
            <Slider />
            <Footer />
        </div>
    )
}

export default Home